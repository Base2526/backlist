# docker-node-mongo

## About
This is a todo web application. It keeps track of chores you need to do and have already done. The purpose for building this web application was to learn about using docker compose to run multiple containers at once which can talk to eachother.

## Running Application Locally
* ```docker-compose build```
* ```docker-compose up```


https://github.com/vinnyoodles/react-native-socket-io-example




// จะส่งไปทุกๆ  socket.on('FromAPI', (messageNew) => ในส่วน reactjs
// socket.emit("FromAPI", response);

// จะส่งไปตามแต่ละ socket.id
// io.to('vwMRV1tla8OILFnWAAAC').emit('FromAPI', 'for your eyes only');

