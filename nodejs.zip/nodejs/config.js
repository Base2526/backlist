var config = {};
config.mongo = {};

// mongo  admin:password@
// config.mongo.url = 'mongodb://mongo:U29ta2lkMDU4ODQ4Mzkx@mongo:27017/banlist';
// config.mongo.url = "mongodb://mongo:27099/bl";

config.mongo.url = "mongodb://mongo:27017/banlist";

module.exports = config;